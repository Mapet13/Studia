package com.tw;

public abstract class AbstractBuffor {

    public abstract void produce(int min, int max);

    public abstract void consume(int min, int max);

}
